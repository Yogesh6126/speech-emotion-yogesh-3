# Speech Emotion Detection (Machine Learning)

Author: Yogesh (GitHub: Yogesh6126)

## Overview
This project demonstrates a simple speech emotion detection pipeline using classic machine learning (Scikit-learn).
The notebook generates synthetic audio samples (so you don't need to download any dataset), extracts audio features (MFCCs, spectral centroid, zero-crossing rate), trains a Random Forest classifier, and evaluates performance.

You can run the notebook directly in Google Colab.

## Files
- `speech_emotion_yogesh.ipynb` - main notebook.
- `requirements.txt` - Python dependencies to install in Colab/local.
- `predictions.csv` - example output produced by the notebook (generated at runtime).

## How to run (Google Colab)
1. Open the notebook in Colab.
2. Run the first cell to install dependencies:
   ```bash
   !pip install -r requirements.txt
   ```
3. Run all cells. The notebook will:
   - generate synthetic audio samples for emotions (happy, sad, angry, neutral),
   - extract MFCC + other features using `librosa`,
   - train a RandomForest classifier (scikit-learn),
   - save `predictions.csv` with model predictions.

## Notes
- This is a portfolio-friendly ML project showcasing feature extraction and model training without heavy GPU needs.
- For production or research, replace synthetic samples with a real labeled dataset (e.g., RAVDESS, CREMA-D, etc.).

Made with ❤️ by Yogesh (Yogesh6126)
